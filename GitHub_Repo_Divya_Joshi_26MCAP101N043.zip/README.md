# Smart Student Performance Analytics System using MATLAB

MCA Mini Project | Manav Rachna International Institute of Research and Studies, School of Computer Applications

**Submitted by:** Divya Joshi | **Roll No.:** 26MCAP101N043 | MCA Semester I (2026-2027)

## Project Summary
A MATLAB mini project that generates 30 fictional student records (attendance, assignment, internal and exam marks) and analyses them using:
- Descriptive statistics (mean, median, mode, range, variance, standard deviation)
- Correlation between attendance and exam marks (r = 0.343)
- Simple linear regression (`polyfit`, `polyval`)
- Group comparison (Group A vs Group B, 15 records each)
- Early-warning flags (attendance < 75% or exam marks < 40)
- A four-chart dashboard: student-wise performance, attendance distribution, actual vs predicted marks, group comparison

> The dataset is synthetic and for demonstration only.

## How to Run
1. Open MATLAB (or MATLAB Online).
2. Open `Source_Code/main.m`.
3. Click **Run**. Results appear in the Command Window and the dashboard opens as a figure.

## Project Structure
```
Source_Code/main.m
Screenshots/dashboard_output.png
Screenshots/command_window_output.png
Screenshots/matlab_workspace.png
README.md
```

## Output
![Dashboard](Screenshots/dashboard_output.png)
![Command Window](Screenshots/command_window_output.png)
